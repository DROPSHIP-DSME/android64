{
	"font-averta-bold": {
            "fontFamily": "hintedavertastdbold"
	},
	"font-averta-semibold": {
            "fontFamily": "hintedavertastdsemibold"
	}
}
