import PasswordInputText from './src/component/passwordInput';

export default PasswordInputText;
