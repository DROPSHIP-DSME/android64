<View style={tw.style('bg-white overflow-hidden shadow rounded-md mx-4')}>
  <View style={tw.style('px-2 py-5')}>

  </View>
</View>
