import { connect } from 'react-redux';
import { ResetPassword } from '../../screens/auth';

const mapStateToProps = (state) => ({
    
});

const mapDispatchToProps = {
    
};

export default connect(mapStateToProps, mapDispatchToProps)(ResetPassword);