

const CommonStrings={
    AppName:"Dropship"
}

export default CommonStrings;

