const RalewayExtraBold = "AvertaStd-Semibold"; //similar GothamBold
const QuestrialRegular = "AvertaStd-Regular"; //  similar GothamBook //Raleway-Medium  //Raleway-Regular
const RalewaySemiBold = "hintedavertastdasemiBold";  // similar GothamMedium
const RalewayLight = "hintedavertastdlight";
const RalewayThin = "hintedavertastdthin";
const SfproSemibold = "AvertaStd-Semibold";
const HomepageBaukastenBold = "hintedavertastdbold"; // Number

export default Fonts = {
    RalewayExtraBold,
    QuestrialRegular,
    RalewaySemiBold,
    RalewayLight,
    RalewayThin,
    SfproSemibold,
    HomepageBaukastenBold
}
