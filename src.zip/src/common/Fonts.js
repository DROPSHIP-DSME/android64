const RalewayExtraBold = "hintedavertaStdextrabold"; //similar GothamBold
const QuestrialRegular = "hintedavertaStdregular"; //  similar GothamBook //Raleway-Medium  //Raleway-Regular
const RalewaySemiBold = "hintedavertastdasemiBold";  // similar GothamMedium
const RalewayLight = "hintedavertastdlight";
const RalewayThin = "hintedavertastdthin";
const SfproSemibold = "hintedavertaStdsemibold";
const HomepageBaukastenBold = "hintedavertastdbold"; // Number

export default Fonts = {
    RalewayExtraBold,
    QuestrialRegular,
    RalewaySemiBold,
    RalewayLight,
    RalewayThin,
    SfproSemibold,
    HomepageBaukastenBold
}
