export const subscriptionEnum = [
    {
     "price":75.00,
     "validity":"1 coupon per month"
    },
    {
     "price":135.00,
     "validity":"3 coupon per month"
    },
    {
     "price":195.00,
     "validity":"5 coupon per month"
    }
];
