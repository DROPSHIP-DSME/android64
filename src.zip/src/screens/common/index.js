import Footer3 from './Footer3';
import Footer2 from './Footer2';
import Sellheader from './Sellheader';
 
export {
    Footer2,
    Footer3,
    Sellheader
}