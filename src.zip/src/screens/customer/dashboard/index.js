import watchlist from './watchlist';
import NameStore from './NameStore';
import clothing from './clothing';
import clothdetails from './clothdetails';

export {
    watchlist,
    NameStore,
    clothing,
    clothdetails
}