import Dashsupportacc from './Dashsupportacc';
import deletaccount from './deletaccount';
import editpassword from './editpassword';

export {
     Dashsupportacc,
     deletaccount,
     editpassword
}