import Shippingdetails from './Shippingdetails';


export {
    Shippingdetails,
}