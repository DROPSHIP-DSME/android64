export const data = [
      {
        id: 1,
        title: 'Processing',
        body:
          'Your order is being processed by the brand and will be updated shortly.',
      },
      {
        id: 2,
        title: 'Shipped',
        body:
          'Your order has been shipped, and will arrive at its destination in the estimated time.',
      },
      {
        id: 3,
        title: 'Delivered',
        body:
          'Your order has arrived and is ready to be picked up!'
      },
      {
        id: 4,
        title: 'Complete',
        body:
          'Your order is complete! Thank you for shopping with Dropship.',
      }
    ];