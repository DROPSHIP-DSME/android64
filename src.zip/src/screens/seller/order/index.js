import Dashorder from './Dashorder'; 
import Dashdetail from './Dashdetail';

export {
    Dashorder,
    Dashdetail
}