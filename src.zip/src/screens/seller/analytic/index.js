import SalesAnalytic from './Dashsale';
import Dashsale from './Dashsale';

export {
    SalesAnalytic,
    Dashsale
}